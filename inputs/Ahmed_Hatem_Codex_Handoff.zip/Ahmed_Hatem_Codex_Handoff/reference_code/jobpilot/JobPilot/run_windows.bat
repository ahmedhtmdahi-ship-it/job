@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 echo Run setup_windows.bat first.
 pause
 exit /b 1
)
:menu
cls
echo JobPilot
echo 1 Search jobs
echo 2 Open review page
echo 3 Show job IDs and status
echo 4 Approve a reviewed job
echo 5 Sign in to an application website
echo 6 Preview one application - no sending
echo 7 Send all approved applications
echo 8 Import one job URL with structured job data
echo 9 Show source support
echo A Search and automatically send clearly eligible applications
echo 0 Exit
set /p jobpilot_choice=Choose: 
if "%jobpilot_choice%"=="0" exit /b
if /i "%jobpilot_choice%"=="A" .venv\Scripts\python.exe jobpilot.py auto
if "%jobpilot_choice%"=="1" .venv\Scripts\python.exe jobpilot.py search
if "%jobpilot_choice%"=="2" .venv\Scripts\python.exe jobpilot.py review
if "%jobpilot_choice%"=="3" .venv\Scripts\python.exe jobpilot.py list
if "%jobpilot_choice%"=="4" goto approve
if "%jobpilot_choice%"=="5" goto login
if "%jobpilot_choice%"=="6" goto preview
if "%jobpilot_choice%"=="7" .venv\Scripts\python.exe jobpilot.py apply --send
if "%jobpilot_choice%"=="8" goto import
if "%jobpilot_choice%"=="9" .venv\Scripts\python.exe jobpilot.py sources
pause
goto menu
:approve
set /p jobpilot_id=Job ID: 
.venv\Scripts\python.exe jobpilot.py approve "%jobpilot_id%"
pause
goto menu
:login
set /p jobpilot_url=HTTPS website URL: 
.venv\Scripts\python.exe jobpilot.py login "%jobpilot_url%"
pause
goto menu
:preview
set /p jobpilot_id=Approved job ID: 
.venv\Scripts\python.exe jobpilot.py apply --id "%jobpilot_id%"
pause
goto menu
:import
set /p jobpilot_url=HTTPS job URL: 
.venv\Scripts\python.exe jobpilot.py import "%jobpilot_url%"
pause
goto menu
