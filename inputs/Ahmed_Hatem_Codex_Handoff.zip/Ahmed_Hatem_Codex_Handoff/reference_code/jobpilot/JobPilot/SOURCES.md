# Source capabilities — 1 November 2026

Actual website compatibility has NOT been tested on the user's accounts. Browser adapters are experimental and stop on changed or unsupported forms. A source appearing here does not mean automatic sending works on it.

| Source | Search / discovery | Submission |
|---|---|---|
| Freelancer | Existing public API; $5/hour floor | Manual bids; price, schedule and fees need review |
| PeoplePerHour | Existing best-effort HTML scanner | Manual |
| Kafiil | Existing best-effort HTML scanner | Manual |
| Khamsat | Existing buyer-request scanner; may be stale/blocked | Manual |
| LinkedIn | Existing guest jobs scanner | Experimental Easy Apply adapter |
| Wuzzuf | Existing best-effort HTML scanner | Manual; external Workable/Lever URL can be imported separately |
| Bayt | Existing best-effort HTML scanner | Manual |
| Remotive / Jobicy / RemoteOK | Existing public feeds | Follow employer's application URL; compatible form only |
| Workable | Import a specific employer JobPosting URL; no site-wide crawler | Experimental labelled HTML form adapter |
| Welo Data | Public Welo Global Lever feed; includes non-Welo teams, screened by role | Experimental Lever form adapter |
| 20four7VA | Career-board links plus JobPosting structured data, when available | Experimental Breezy form adapter |
| Justlife | Career-board links plus JobPosting structured data, when available | Experimental JazzHR form adapter |
| Indeed / GulfTalent / Dr.Job | Not implemented | Manual |
| Turing / micro1 | Not implemented; account/onboarding/assessment flow | Manual |
| Upwork / Ureed / Mostaql / Contra | Not implemented | Manual proposals |
| Fiverr | Not implemented | Service/gig publishing is separate from job applications |
| CS Outsource / Sira / SLICEY | Skipped — exact links not supplied | Skipped |

Official entry points verified while building:
- https://www.turing.com/jobs
- https://www.micro1.ai/experts
- https://jobs.lever.co/weloglobal
- https://20four7va.breezy.hr/
- https://career.justlife.com/

No global success rate or live compatibility guarantee is claimed. search_status.json reports empty/error sources; application status is updated only after explicit confirmation following a submit click.
