"""Local job search, application preparation and browser form submission.
No credentials in source. No CAPTCHA bypass. No LLM or paid API required.
"""
from __future__ import annotations
import argparse, contextlib, datetime as dt, hashlib, html, json, os, re
import sqlite3, sys, time, urllib.parse, urllib.request
from pathlib import Path
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parent
TERMINAL = {'submitted', 'submitting', 'uncertain'}
CONFIRMATION = re.compile(r'(?:your application (?:has been|was) (?:successfully )?(?:submitted|received|sent)|application submitted|thank you for applying|thanks for applying|تم إرسال طلبك|تم تقديم طلبك)', re.I)
# Deliberately exclude generic "success" and "thank you".

def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def config(): return json.loads((ROOT/'settings.json').read_text(encoding='utf-8'))
def canonical(url):
    u=urllib.parse.urlsplit(url)
    if u.scheme!='https' or not u.hostname or u.username or u.password: raise ValueError('Only HTTPS application URLs are allowed')
    if u.hostname in {'localhost','127.0.0.1','::1'}: raise ValueError('Local target is not an application site')
    # Job IDs in query strings matter (e.g. Indeed jk); remove only tracking keys.
    query=urllib.parse.urlencode([(k,v) for k,v in urllib.parse.parse_qsl(u.query) if not k.startswith('utm_') and k not in {'trk','trackingId','refId'}])
    return urllib.parse.urlunsplit(('https',u.netloc.lower(),u.path.rstrip('/'),query,''))
def host_allowed(url, cfg):
    h=urllib.parse.urlsplit(url).hostname or ''
    return any(h==x or h.endswith('.'+x) for x in cfg['application_hosts'])
def db():
    con=sqlite3.connect(ROOT/'jobpilot.sqlite',timeout=30)
    con.row_factory=sqlite3.Row
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('''CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY, url TEXT UNIQUE NOT NULL, title TEXT NOT NULL, company TEXT,
      payload TEXT NOT NULL, status TEXT DEFAULT 'needs_review', approval TEXT,
      updated TEXT, reason TEXT, evidence TEXT)''')
    return con
def uid(url): return hashlib.sha256(canonical(url).encode()).hexdigest()[:20]
def save_jobs(rows):
    count=0
    with db() as con:
        for row in rows:
            try: url=canonical(row['url'])
            except (ValueError,KeyError): continue
            if not row.get('title'): continue
            row={**row,'url':url}
            con.execute('''INSERT INTO jobs(id,url,title,company,payload,updated) VALUES(?,?,?,?,?,?)
                ON CONFLICT(url) DO UPDATE SET title=excluded.title,company=excluded.company,
                payload=excluded.payload,updated=excluded.updated''',
                (uid(url),url,row['title'],row.get('company',''),json.dumps(row,ensure_ascii=False),now()))
            count+=1
    return count

def salary_floor_ok(row,cfg):
    # A source conversion must be supplied; a dollar sign alone is ambiguous.
    if row.get('hourly'):
        ceiling=row.get('hourly_max_usd')
        if ceiling is not None and ceiling < cfg['minimum_hourly_usd']: return False
    return True

def approval_hash(row):
    fields={k:row.get(k) for k in ['url','title','company','proposal','cv_category','hourly','bid','usd','quotation','days','desc','loc','hourly_max_usd']}
    return hashlib.sha256(json.dumps(fields,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def location_check(text):
    t=' '.join(text.lower().split())
    denied=[r'\b(?:us|usa|uk|eu|europe|canada|india|philippines|united states|united kingdom)[ -]only\b',
            r'\bmust (?:reside|be based|be located|live) in (?:the )?(?:us|usa|uk|canada|india|philippines|united states|united kingdom)\b',
            r'\b(?:on[ -]site|onsite|hybrid)\b',r'\b(?:not|no longer) accepting applications\b',r'\bnot an active job opening\b']
    if any(re.search(x,t) for x in denied): return 'blocked'
    if re.search(r'\b(?:remote|work from home|work from anywhere|عن بعد)\b',t) and re.search(r'\b(?:egypt|worldwide|anywhere in the world|globally)\b',t): return 'eligible'
    return 'unknown'

def cv_for(title):
    import search_legacy
    return search_legacy.cv_for(title)

def proposal(row):
    import search_legacy
    return row.get('proposal') or (search_legacy.proposal_en(row['title'], search_legacy.pick(row['title'])) if row.get('kind')=='project' else search_legacy.cover(row['title'],row.get('company','')))

class PageData(HTMLParser):
    def __init__(self):
        super().__init__(); self.ld=[]; self.links=[]; self.inside=False; self.parts=[]
    def handle_starttag(self, tag, attrs):
        d=dict(attrs)
        if tag=='script' and d.get('type','').lower()=='application/ld+json': self.inside=True; self.parts=[]
        if tag=='a' and d.get('href'): self.links.append(d['href'])
    def handle_data(self,data):
        if self.inside:self.parts.append(data)
    def handle_endtag(self,tag):
        if tag=='script' and self.inside:
            self.inside=False
            try:self.ld.append(json.loads(''.join(self.parts)))
            except ValueError:pass

def fetch(url):
    request=urllib.request.Request(canonical(url),headers={'User-Agent':'JobPilot personal job search/1.0'})
    with urllib.request.urlopen(request,timeout=25) as r:
        if urllib.parse.urlsplit(r.url).scheme!='https':raise ValueError('Non-HTTPS redirect')
        return r.read(8_000_000).decode('utf-8','replace')
def flatten(node):
    if isinstance(node,list):
        for item in node: yield from flatten(item)
    elif isinstance(node,dict):
        typ=node.get('@type',[])
        if typ=='JobPosting' or isinstance(typ,list) and 'JobPosting' in typ: yield node
        for key,value in node.items():
            if key!='@context' and isinstance(value,(dict,list)): yield from flatten(value)

def import_page(url):
    parser=PageData(); parser.feed(fetch(url)); rows=[]
    for node in flatten(parser.ld):
        desc=html.unescape(re.sub('<[^>]+>',' ',node.get('description','')))
        title=html.unescape(node.get('title',''))
        company=node.get('hiringOrganization') or {}
        if isinstance(company,dict):company=company.get('name','')
        salary=node.get('baseSalary') or {}; val=salary.get('value',{}) if isinstance(salary,dict) else {}
        hourly=isinstance(val,dict) and val.get('unitText','').upper() in {'HOUR','HOURLY'}
        usd_max=(val.get('maxValue',val.get('value')) if hourly and salary.get('currency')=='USD' else None)
        geography=node.get('applicantLocationRequirements') or []
        if isinstance(geography,dict):geography=[geography]
        names=[str(x.get('name','')) for x in geography if isinstance(x,dict)]
        if node.get('jobLocationType')=='TELECOMMUTE':desc+=' Remote '
        desc+=' '+' '.join(names)
        rows.append({'url':node.get('url') or url,'title':title,'company':company,'desc':desc,
                     'kind':'job','site':urllib.parse.urlsplit(url).hostname,'hourly':hourly,
                     'hourly_max_usd':usd_max,'source':'JobPosting structured data'})
    return rows,parser.links

def search():
    import search_legacy as old
    cfg=config(); rows=[]; report=[]
    for fn in [old.freelancer,old.pph,old.khamsat,old.kafiil,old.remotive,old.jobicy,old.remoteok,old.linkedin,old.wuzzuf,old.bayt]:
        try:
            found=fn()
            for row in found:
                row['kind']='project' if 'bid' in row else 'job'
                if not old.title_ok(row['title']) or not role_relevant(row['title']):continue
                if row['kind']=='job' and row.get('days',-1)>old.JOB_MAX_DAYS:continue
                if row['kind']=='project' and row.get('age',-1)>old.MAX_HOURS_OLD:continue
                row['cv_category']=cv_for(row['title']); row['proposal']=proposal(row)
                rows.append(row)
            report.append({'source':fn.__name__,'found':len(found),'status':'fetched' if found else 'empty_or_blocked_check_console'})
        except Exception as exc:report.append({'source':fn.__name__,'status':'error','error':str(exc)})
    # Welo Data: employer board via public Lever feed, not a guessed job page.
    try:
        data=json.loads(fetch('https://api.lever.co/v0/postings/weloglobal?mode=json'))
        for j in data:
            title=j.get('text',''); cats=j.get('categories',{})
            if not role_relevant(title) or not old.title_ok(title):continue
            desc=j.get('descriptionPlain','')+' '+str(cats.get('location',''))+' '+str(j.get('workplaceType',''))
            rows.append({'url':j['hostedUrl'],'title':title,'company':'Welo Global','kind':'job','site':'Welo Data',
                         'desc':desc,'cv_category':cv_for(title),'proposal':old.cover(title,'Welo Global')})
        report.append({'source':'Welo Data','status':'fetched'})
    except Exception as exc:report.append({'source':'Welo Data','status':'error','error':str(exc)})
    # Structured career-page discovery. If pages expose no JSON-LD, report it explicitly.
    for url in cfg.get('extra_career_pages',[]):
        try:
            found,links=import_page(url)
            host=urllib.parse.urlsplit(url).hostname
            candidates=[]
            for link in links:
                target=urllib.parse.urljoin(url,link)
                if urllib.parse.urlsplit(target).hostname==host and re.search(r'/(?:p|apply|j|jobs|careers)/[^/?]+',target):
                    if target not in candidates:candidates.append(target)
            for target in candidates:
                items,_=import_page(target);found.extend(items);time.sleep(.4)
            found=[r for r in found if role_relevant(r['title']) and old.title_ok(r['title'])]
            rows.extend(found);report.append({'source':url,'status':'fetched' if found else 'no_structured_jobs','found':len(found)})
        except Exception as exc:report.append({'source':url,'status':'error','error':str(exc)})
    for row in rows: row.setdefault('cv_category',cv_for(row['title']));row.setdefault('proposal',proposal(row))
    count=save_jobs([r for r in rows if salary_floor_ok(r,cfg)])
    (ROOT/'search_status.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Saved/updated {count} opportunities. Source health: search_status.json')
    list_jobs()

def qualify():
    """Automatically prepare clearly eligible job applications; ambiguous rows remain for review."""
    import search_legacy as old
    cfg=config()
    with db() as con: candidates=list(con.execute("SELECT * FROM jobs WHERE status='needs_review'"))
    total=0
    for row in candidates:
        data=json.loads(row['payload'])
        if data.get('kind')!='job' or not host_allowed(data['url'],cfg):continue
        if not old.title_ok(data['title']) or not role_relevant(data['title']):continue
        # Use the individual job's structured description, never search-page or footer text.
        if data.get('source')!='JobPosting structured data':
            try:
                postings,_=import_page(data['url'])
                matches=[x for x in postings if x['title'].lower().strip()==data['title'].lower().strip()]
                if len(matches)!=1:continue
                data={**data,**matches[0], 'url':row['url']}
            except Exception:continue
        if location_check(data.get('desc',''))!='eligible':continue
        if not salary_floor_ok(data,cfg):event(row['id'],'rejected','Hourly ceiling is below $5');continue
        # An hourly role with undisclosed/ambiguous pay cannot be automatically committed.
        if data.get('hourly') and data.get('hourly_max_usd') is None:continue
        data['cv_category']=cv_for(data['title']);data['proposal']=proposal(data)
        if not (ROOT/cfg['cv_files'][data['cv_category']]).is_file():continue
        with db() as con:
            con.execute("UPDATE jobs SET payload=?,approval=?,status='approved',reason=?,updated=? WHERE id=? AND status='needs_review'",
                        (json.dumps(data,ensure_ascii=False),approval_hash(data),'Automatically qualified: role match and explicit remote/Egypt or worldwide eligibility',now(),row['id']))
        total+=1
    print('Automatically qualified',total,'clearly eligible applications. Others require review.')

def role_relevant(title):
    return bool(re.search(r'excel|power bi|reporting|data entry|data analyst|operations|coordinator|assistant|marketing|community|sales|business development|trainer|training|learning|customer (?:success|support)|monitoring|evaluation',title,re.I))

def list_jobs():
    with db() as con:
        for row in con.execute('SELECT id,status,title,reason FROM jobs ORDER BY updated DESC'):
            print(row['id'], '|',row['status'],'|',row['title'], '|', row['reason'] or '')

def export_review():
    with db() as con: rows=list(con.execute('SELECT * FROM jobs ORDER BY updated DESC'))
    cards=[]
    for r in rows:
        data=json.loads(r['payload'])
        cards.append('<article><h2>'+html.escape(r['title'])+'</h2><p>'+html.escape(r['id']+' | '+r['status'])+'</p><a href="'+html.escape(r['url'],quote=True)+'" target="_blank" rel="noopener">Open job</a><p>CV: '+html.escape(data.get('cv_category',cv_for(r['title'])))+'</p><textarea>'+html.escape(proposal(data))+'</textarea><p>'+html.escape(r['reason'] or '')+'</p></article>')
    out=ROOT/'review.html'
    out.write_text('<!doctype html><meta charset="utf-8"><title>JobPilot review</title><style>body{font:16px Arial;background:#eef2f7;max-width:950px;margin:30px auto}article{background:white;padding:20px;margin:16px 0;border-radius:12px}textarea{width:100%;height:190px}</style><h1>JobPilot — review queue</h1><p>Review the full posting, CV, location and project quotation before approval. No application-count cap.</p>'+''.join(cards),encoding='utf-8')
    import webbrowser;webbrowser.open(out.as_uri());print(out)

def approve(jid):
    with db() as con:
        row=con.execute('SELECT * FROM jobs WHERE id=?',(jid,)).fetchone()
        if not row:raise ValueError('Unknown job ID')
        if row['status'] in TERMINAL:raise ValueError('Submitted or uncertain application cannot be approved again')
        data=json.loads(row['payload']);data.setdefault('cv_category',cv_for(data['title']));data.setdefault('proposal',proposal(data))
        cfg=config()
        if not salary_floor_ok(data,cfg):raise ValueError('Below hourly floor')
        cv=ROOT/cfg['cv_files'][data['cv_category']]
        if not cv.is_file():raise ValueError(f'Missing CV: {cv}')
        # Review approval covers geographic suitability and the selected CV, not unknown mandatory answers.
        con.execute('UPDATE jobs SET payload=?,approval=?,status=?,reason=?,updated=? WHERE id=?',
                    (json.dumps(data,ensure_ascii=False),approval_hash(data),'approved','Reviewed by user',now(),jid))
    print('Approved',jid)

def event(jid,status,reason='',evidence=None):
    with db() as con:con.execute('UPDATE jobs SET status=?,reason=?,evidence=?,updated=? WHERE id=?',(status,reason,evidence,now(),jid))

# Every field must be matched to a known fact or an exact, user-configured answer.
FIELD_JS=r'''els => els.map((e,i)=>({i,tag:e.tagName.toLowerCase(),type:(e.type||'').toLowerCase(),name:e.name||'',id:e.id||'',value:e.value||'',required:e.required||e.getAttribute('aria-required')==='true',label:[...(e.labels||[])].map(l=>l.innerText).join(' ').trim()||e.getAttribute('aria-label')||e.placeholder||'',visible:!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length),options:e.options?[...e.options].map(o=>({value:o.value,label:o.text})):[]}))'''

def answer_for(field,app,cfg,draft):
    label=' '.join(field['label'].lower().split()).strip(' *✱✳')
    # Exact-question mapping first. Never infer authorization, salary or years of experience.
    for q,a in cfg.get('question_answers',{}).items():
        if label==q.lower().strip():return a
    keys=[(r'^(?:first name|given name|الاسم الأول)\s*\*?$', 'first_name'),
          (r'^(?:last name|family name|surname|اسم العائلة)\s*\*?$', 'last_name'),
          (r'^(?:full name|name|your name|الاسم الكامل)\s*\*?$', 'full_name'),
          (r'^(?:email|email address|your email|البريد الإلكتروني)\s*\*?$', 'email'),
          (r'^(?:phone|phone number|mobile|mobile phone|telephone|رقم الهاتف)\s*\*?$', 'phone'),
          (r'^(?:linkedin|linkedin profile|linkedin url|linkedin profile url)\s*\*?$', 'linkedin'),
          (r'^(?:city|current city)\s*\*?$', 'city'),
          (r'^(?:country|country of residence)\s*\*?$', 'country')]
    for pattern,key in keys:
        if re.fullmatch(pattern,label):return app[key]
    if re.fullmatch(r'(?:cover letter|covering letter|message to hiring manager)\s*\*?',label):return draft
    return None

def fill_form(scope,app,cfg,data):
    locator=scope.locator('input,textarea,select');fields=locator.evaluate_all(FIELD_JS)
    unresolved=[]
    for f in fields:
        if f['type'] in {'hidden','submit','button','reset','image'}:continue
        el=locator.nth(f['i'])
        if f['type']=='file':
            # Never upload a CV into an arbitrary portfolio/identity/cover-letter attachment.
            label=f['label'].lower()
            hint=label+' '+f['name'].lower()+' '+f['id'].lower()
            if any(w in hint for w in ['resume','résumé','curriculum','cv']):
                cv=ROOT/cfg['cv_files'][data['cv_category']]
                el.set_input_files(str(cv))
            elif f['required']:unresolved.append('Unknown attachment: '+f['label'])
            continue
        if not f['visible']:continue
        if f['type'] in {'checkbox','radio'}:
            if f['type']=='checkbox' and not f['required'] and re.search(r'follow|newsletter|marketing emails|job alerts',f['label'],re.I):
                el.uncheck();continue
            # Consents and screening answers are never automatically ticked.
            answer=answer_for(f,app,cfg,data['proposal'])
            checked=el.is_checked()
            if answer is True:el.check()
            elif answer is False:el.uncheck()
            elif f['required'] and not checked:unresolved.append(f['label'] or f['name'])
            continue
        answer=answer_for(f,app,cfg,data['proposal'])
        if answer is not None:
            if f['tag']=='select':
                options=[o for o in f['options'] if o['label'].strip().lower()==str(answer).lower() or o['value']==str(answer)]
                if len(options)==1:el.select_option(options[0]['value'])
                else:unresolved.append(f['label']+' (select option)')
            else:el.fill(str(answer))
        elif f['required']:
            # Even a prefilled unknown required answer is not accepted as a verified fact.
            unresolved.append(f['label'] or f['name'] or f['id'] or 'Unlabelled required input')
    return unresolved

def visible_matches(scope,role,pattern):
    matches=scope.get_by_role(role,name=re.compile(pattern,re.I))
    return [matches.nth(i) for i in range(matches.count()) if matches.nth(i).is_visible()]

def request_submission(scope,page,jid,context_text,confirmation_timeout=20):
    targets=visible_matches(scope,'button',r'^(?:submit application|send application|submit|apply now|إرسال الطلب|تقديم الطلب)$')
    if len(targets)!=1:return 'needs_review','Final submit button is missing or ambiguous'
    if re.search(r'\b(?:connects|buy credits|purchase|subscription|pay to apply|application fee|bid now)\b',context_text,re.I):
        return 'needs_review','Paid/proposal workflow requires a dedicated adapter and budget'
    # Do not accept a confirmation that existed before we clicked.
    before=CONFIRMATION.search(page.locator('body').inner_text())
    if before:return 'needs_review','Page already contains confirmation; check application history'
    event(jid,'submitting','Submission about to be clicked; will not retry automatically')
    try:
        targets[0].click()
        deadline=time.monotonic()+confirmation_timeout
        while time.monotonic()<deadline:
            body=page.locator('body').inner_text()
            hit=CONFIRMATION.search(body)
            if hit:return 'submitted',hit.group(0)
            page.wait_for_timeout(400)
        return 'uncertain','Submit clicked but no explicit application confirmation appeared'
    except Exception as exc:return 'uncertain','Submission may have been sent: '+str(exc)[:250]

def process_application(page,row,cfg,send):
    data=json.loads(row['payload']);jid=row['id']
    if row['approval']!=approval_hash(data):return 'needs_review','Posting/draft changed since review'
    if not host_allowed(data['url'],cfg):return 'manual_required','No tested adapter for this host; use the saved draft'
    if data.get('kind')=='project':return 'manual_required','Freelance bid/payment adapter is not implemented; quotation must be reviewed'
    page.goto(data['url'],wait_until='domcontentloaded',timeout=45000)
    page.wait_for_timeout(1000)
    if not host_allowed(page.url,cfg):return 'manual_required','Redirected to a different application provider; review host first'
    body=page.locator('body').inner_text()
    if re.search(r'\b(?:captcha|verify you are human|security verification)\b',body,re.I):return 'login_required','Complete the security check manually; no bypass attempted'
    if location_check(data.get('desc','')+' '+body)=='blocked':return 'rejected','Explicit geographic/onsite/closed-posting restriction'
    linked='linkedin.com' in (urllib.parse.urlsplit(page.url).hostname or '')
    if linked:
        easy=visible_matches(page,'button',r'^(?:easy apply|easy apply to .+|التقديم السهل)$')
        if not easy:return 'manual_required','LinkedIn Easy Apply unavailable or login required'
        if len(easy)!=1:return 'needs_review','Ambiguous Easy Apply button'
        easy[0].click();page.wait_for_timeout(500)
    else:
        # Do not click arbitrary page buttons: only an explicit application CTA when no form is present.
        if page.locator('input:not([type=hidden]),textarea').count()==0:
            buttons=visible_matches(page,'button',r'^(?:apply|apply now|apply for this job|apply for this position)$')
            links=visible_matches(page,'link',r'^(?:apply|apply now|apply for this job|apply for this position)$')
            targets=buttons+links
            if len(targets)==1:targets[0].click();page.wait_for_timeout(700)
    if not host_allowed(page.url,cfg):return 'manual_required','External application host needs review'
    for step in range(12):
        dialogs=page.get_by_role('dialog')
        visible=[dialogs.nth(i) for i in range(dialogs.count()) if dialogs.nth(i).is_visible()]
        if linked and len(visible)!=1:return 'needs_review','Expected one Easy Apply dialog'
        forms=page.locator('form')
        active_forms=[forms.nth(i) for i in range(forms.count()) if forms.nth(i).is_visible() and forms.nth(i).locator('input,textarea,select').count()]
        if linked:scope=visible[0]
        elif len(active_forms)==1:scope=active_forms[0]
        else:return 'needs_review','Expected one visible application form; provider may use an iframe/custom widget'
        app_hints=scope.locator('input[type=file]').count() or re.search(r'cover letter|résumé|resume|curriculum vitae',scope.inner_text(),re.I)
        if not linked and not app_hints:return 'needs_review','Form is not identifiable as a job application'
        errors=fill_form(scope,cfg['applicant'],cfg,data)
        if errors:return 'needs_answers',' | '.join(dict.fromkeys(errors))
        invalid=scope.locator('input:invalid,textarea:invalid,select:invalid')
        if any(invalid.nth(i).is_visible() for i in range(invalid.count())):
            return 'needs_answers','Browser form validation failed; inspect inputs'
        custom=scope.locator('[aria-required=true]:not(input):not(select):not(textarea)')
        if any(custom.nth(i).is_visible() for i in range(custom.count())):
            return 'needs_answers','Custom required control needs manual completion'
        scope_text=scope.inner_text()
        finals=visible_matches(scope,'button',r'^(?:submit application|send application|submit|apply now|إرسال الطلب|تقديم الطلب)$')
        if finals:
            if not send:return 'ready','Form filled; preview only, submit not clicked'
            return request_submission(scope,page,jid,scope_text)
        next_buttons=visible_matches(scope,'button',r'^(?:next|continue|review|review application|التالي|متابعة)$')
        if len(next_buttons)!=1:return 'needs_review','No unambiguous next/review/submit button'
        before=scope_text
        next_buttons[0].click();page.wait_for_timeout(500)
        if scope.inner_text()==before:return 'needs_review','Form did not advance; inspect validation errors'
    return 'needs_review','Multi-step form exceeded 12 steps'

@contextlib.contextmanager
def process_lock():
    # One writer/browser runner per package prevents concurrent duplicate submissions.
    path=ROOT/'runner.lock'
    try:fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError:raise RuntimeError('Runner already active, or stale runner.lock after a crash. Verify browser/history before removing it.')
    try:
        os.write(fd,str(os.getpid()).encode());os.close(fd);yield
    finally:path.unlink(missing_ok=True)

def run_browser(login=None,send=False,jid=None):
    from playwright.sync_api import sync_playwright
    cfg=config()
    with process_lock(),sync_playwright() as p:
        context=p.chromium.launch_persistent_context(str(ROOT/'browser_profile'),headless=False,accept_downloads=False)
        context.set_default_timeout(8000)
        page=context.pages[0] if context.pages else context.new_page()
        try:
            if login:
                url=canonical(login)
                if not host_allowed(url,cfg):raise ValueError('Login URL is not in application_hosts')
                page.goto(url);input('Sign in yourself in the browser. Press Enter here when finished: ');return
            with db() as con:
                # Crash after claiming => uncertain; never resubmit silently.
                con.execute("UPDATE jobs SET status='uncertain',reason='Previous run interrupted; check application history' WHERE status='processing'")
                rows=list(con.execute("SELECT * FROM jobs WHERE status IN ('approved','ready')"+(' AND id=?' if jid else ''),(jid,) if jid else ()))
            for row in rows:
                with db() as con:
                    duplicate=con.execute("SELECT id FROM jobs WHERE id<>? AND lower(trim(title))=lower(trim(?)) AND lower(trim(company))=lower(trim(?)) AND company<>'' AND status IN ('submitted','submitting','uncertain','processing')",(row['id'],row['title'],row['company'])).fetchone()
                if duplicate:
                    event(row['id'],'duplicate','Same employer/title already attempted: '+duplicate['id']);continue
                print('Processing:',row['title'])
                event(row['id'],'processing')
                try:status,reason=process_application(page,row,cfg,send)
                except Exception as exc:status,reason='needs_review',str(exc)[:500]
                # If an exception escapes after submit, preserve the non-retry state.
                with db() as con:current=con.execute('SELECT status FROM jobs WHERE id=?',(row['id'],)).fetchone()[0]
                if current=='submitting' and status not in {'submitted','uncertain'}:status='uncertain'
                event(row['id'],status,reason,reason if status=='submitted' else None)
                print(status,reason)
                if not send and jid:input('Review the filled form in the browser; press Enter to close: ')
                page.wait_for_timeout(1200)
        finally:context.close()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='command',required=True)
    for name in ['search','list','review','sources','qualify','auto']:sub.add_parser(name)
    im=sub.add_parser('import');im.add_argument('url')
    ap=sub.add_parser('approve');ap.add_argument('id')
    lo=sub.add_parser('login');lo.add_argument('url')
    ru=sub.add_parser('apply');ru.add_argument('--send',action='store_true');ru.add_argument('--id')
    args=p.parse_args()
    if args.command=='search':search()
    elif args.command=='list':list_jobs()
    elif args.command=='qualify':qualify()
    elif args.command=='auto':search();qualify();run_browser(send=True)
    elif args.command=='review':export_review()
    elif args.command=='sources':print((ROOT/'SOURCES.md').read_text(encoding='utf-8'))
    elif args.command=='import':
        rows,_=import_page(args.url)
        for row in rows:row['cv_category']=cv_for(row['title']);row['proposal']=proposal(row)
        print('Imported',save_jobs(rows),'structured job postings')
    elif args.command=='approve':approve(args.id)
    elif args.command=='login':run_browser(login=args.url)
    elif args.command=='apply':run_browser(send=args.send,jid=args.id)

if __name__=='__main__':
    try:main()
    except (ValueError,RuntimeError,KeyboardInterrupt) as exc:print(str(exc),file=sys.stderr);sys.exit(1)
