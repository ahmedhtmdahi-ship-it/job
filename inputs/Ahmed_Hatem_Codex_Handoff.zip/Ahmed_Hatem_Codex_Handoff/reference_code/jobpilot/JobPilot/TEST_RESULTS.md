# Validation

- 10 deterministic Python tests passed: URL identity and host validation, hourly floor, geographic restrictions, durable status retention, exact-answer matching, confirmation specificity, process locking, JobPosting extraction and automatic qualification.
- Browser integration tests supplied (10 cases), but NOT RUN successfully: the environment denied Chromium's socket initialization. No website submission or live-account test was completed.
- CV copies: phone/end date text checks passed on all five PDFs. Rendered all five pages and visually inspected the contact sheet.
- Python compilation and CLI --help succeeded.

Run the browser tests on Windows after setup before relying on automatic sending. A future successful browser-fixture run still would not establish compatibility with all live providers.
