"""Browser integration tests. All network requests are intercepted as local fixtures."""
import json, sys, tempfile, unittest, shutil
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import jobpilot as j
from playwright.sync_api import sync_playwright

APP={'full_name':'Ahmed Hatem Dahi','first_name':'Ahmed','last_name':'Hatem Dahi','email':'ahmedhtmdahi@gmail.com','phone':'+201144064593','linkedin':'https://www.linkedin.com/in/example','city':'Assiut'}
FORM='''<h1>Operations coordinator</h1><p>Remote worldwide</p><form onsubmit="event.preventDefault();document.body.innerHTML='<h1>Your application has been submitted</h1>'">
<label>Full name<input name="name" required></label><label>Email address<input type=email required></label>
<label>Phone number<input type=tel required></label><label>Resume<input type=file required></label>
<label>Cover letter<textarea required></textarea></label>{extra}<button type=submit>Submit application</button></form>'''
class BrowserTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.pw=sync_playwright().start()
  try: cls.browser=cls.pw.chromium.launch(headless=True,executable_path=shutil.which('chromium') or None,args=['--no-sandbox'])
  except Exception:
   cls.pw.stop();raise
 @classmethod
 def tearDownClass(cls):cls.browser.close();cls.pw.stop()
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.patch=patch.object(j,'ROOT',Path(self.tmp.name));self.patch.start()
  (j.ROOT/'cv.pdf').write_bytes(b'%PDF-1.4 test fixture')
  self.cfg={'applicant':APP,'cv_files':{'operations':'cv.pdf'},'question_answers':{},'application_hosts':['jobs.lever.co'],'minimum_hourly_usd':5}
  self.data={'url':'https://jobs.lever.co/test/123','title':'Operations coordinator','company':'Test','proposal':'Verified draft','cv_category':'operations','kind':'job','desc':'Remote worldwide'}
  j.save_jobs([self.data]);self.jid=j.uid(self.data['url'])
  with j.db() as con:
   con.execute("UPDATE jobs SET approval=?,status='approved' WHERE id=?",(j.approval_hash(self.data),self.jid))
   self.row=dict(con.execute('SELECT * FROM jobs').fetchone())
  self.ctx=self.browser.new_context();self.page=self.ctx.new_page();self.page.set_default_timeout(2000)
 def tearDown(self):self.ctx.close();self.patch.stop();self.tmp.cleanup()
 def route(self,content):self.page.route('**/*',lambda route:route.fulfill(status=200,content_type='text/html',body=content))
 def test_preview_fills_uploads_but_never_sends(self):
  self.route(FORM.format(extra=''))
  status,_=j.process_application(self.page,self.row,self.cfg,False)
  self.assertEqual(status,'ready')
  self.assertEqual(self.page.get_by_label('Full name').input_value(),APP['full_name'])
  self.assertEqual(self.page.get_by_label('Resume').evaluate('e=>e.files[0].name'),'cv.pdf')
  self.assertIsNone(j.CONFIRMATION.search(self.page.inner_text('body')))
 def test_send_requires_postclick_confirmation(self):
  self.route(FORM.format(extra=''))
  status,reason=j.process_application(self.page,self.row,self.cfg,True)
  self.assertEqual(status,'submitted');self.assertIn('application',reason)
 def test_unknown_required_and_prefilled_are_blocked(self):
  self.route(FORM.format(extra='<label>Work authorization<input required value="Yes"></label>'))
  status,reason=j.process_application(self.page,self.row,self.cfg,True)
  self.assertEqual(status,'needs_answers');self.assertIn('Work authorization',reason)
 def test_unapproved_changed_draft_blocks(self):
  row={**self.row,'approval':'old'}
  status,_=j.process_application(self.page,row,self.cfg,True);self.assertEqual(status,'needs_review')
 def test_unknown_required_checkbox_is_not_ticked(self):
  self.route(FORM.format(extra='<label>Accept privacy terms<input type=checkbox required></label>'))
  status,_=j.process_application(self.page,self.row,self.cfg,True)
  self.assertEqual(status,'needs_answers');self.assertFalse(self.page.get_by_label('Accept privacy terms').is_checked())
 def test_blocked_location(self):
  self.route(FORM.format(extra='').replace('Remote worldwide','Remote US only'))
  status,_=j.process_application(self.page,self.row,self.cfg,True);self.assertEqual(status,'rejected')
 def test_ambiguous_submit_button_blocks(self):
  self.route(FORM.format(extra='<button type=button>Submit application</button>'))
  status,_=j.process_application(self.page,self.row,self.cfg,True);self.assertEqual(status,'needs_review')
 def test_form_without_application_evidence_blocks(self):
  self.route('<form><label>Email<input required></label><button>Submit</button></form>')
  status,_=j.process_application(self.page,self.row,self.cfg,True);self.assertEqual(status,'needs_review')
 def test_failed_submit_is_uncertain(self):
  self.page.set_content('<form onsubmit="event.preventDefault()"><button>Submit application</button></form>')
  status,_=j.request_submission(self.page.locator('form'),self.page,self.jid,'Submit application',confirmation_timeout=0)
  self.assertEqual(status,'uncertain')
 def test_multistep_linkedin_dialog(self):
  self.cfg['application_hosts']=['linkedin.com'];data={**self.data,'url':'https://www.linkedin.com/jobs/view/123'}
  row={**self.row,'payload':json.dumps(data),'approval':j.approval_hash(data)}
  content='''<p>Remote worldwide</p><button onclick="document.querySelector('[role=dialog]').hidden=false">Easy Apply</button>
  <div role=dialog hidden><label>Email address<input type=email required></label><button onclick="this.parentElement.innerHTML='<label>Cover letter<textarea required></textarea></label><button onclick=\\"document.body.innerHTML=\'Your application has been submitted\'\\">Submit application</button>'">Next</button></div>'''
  # Use DOM-building script rather than fragile nested quote markup.
  content='''<p>Remote worldwide</p><button id=easy>Easy Apply</button><div role=dialog hidden></div><script>
  const d=document.querySelector('[role=dialog]');document.querySelector('#easy').onclick=()=>{d.hidden=false;d.innerHTML='<label>Email address<input type=email required></label><button id=next>Next</button>';document.querySelector('#next').onclick=()=>{d.innerHTML='<label>Cover letter<textarea required></textarea></label><button id=send>Submit application</button>';document.querySelector('#send').onclick=()=>document.body.innerHTML='Your application has been submitted';};};</script>'''
  self.route(content)
  status,_=j.process_application(self.page,row,self.cfg,True);self.assertEqual(status,'submitted')
if __name__=='__main__':unittest.main()
