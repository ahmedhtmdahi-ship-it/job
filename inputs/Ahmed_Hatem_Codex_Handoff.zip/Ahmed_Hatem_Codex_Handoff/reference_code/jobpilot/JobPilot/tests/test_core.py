import json, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import jobpilot as j

class CoreTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.patch=patch.object(j,'ROOT',Path(self.tmp.name));self.patch.start()
 def tearDown(self): self.patch.stop();self.tmp.cleanup()
 def test_url_preserves_job_identity(self):
  self.assertEqual(j.canonical('https://www.indeed.com/viewjob?jk=123&utm_source=x'),'https://www.indeed.com/viewjob?jk=123')
  self.assertNotEqual(j.uid('https://www.indeed.com/viewjob?jk=1'),j.uid('https://www.indeed.com/viewjob?jk=2'))
  for bad in ['http://example.com','https://user:pass@example.com','javascript:alert(1)','https://localhost/foo']:
   with self.assertRaises(ValueError):j.canonical(bad)
 def test_host_suffix(self):
  c={'application_hosts':['linkedin.com']}
  self.assertTrue(j.host_allowed('https://www.linkedin.com/jobs',c))
  self.assertFalse(j.host_allowed('https://linkedin.com.evil.com',c))
 def test_floor(self):
  self.assertFalse(j.salary_floor_ok({'hourly':True,'hourly_max_usd':4},{'minimum_hourly_usd':5}))
  self.assertTrue(j.salary_floor_ok({'hourly':True,'hourly_max_usd':5},{'minimum_hourly_usd':5}))
 def test_unknown_geography_and_restrictions(self):
  self.assertEqual(j.location_check('Remote position'),'unknown')
  self.assertEqual(j.location_check('Fully remote worldwide. US only.'),'blocked')
  self.assertEqual(j.location_check('Remote role based in Egypt'),'eligible')
  self.assertEqual(j.location_check('Remote Egypt. This is not an active job opening.'),'blocked')
 def test_discovery_preserves_submission_and_approval(self):
  row={'url':'https://example.com/jobs/1','title':'Coordinator','company':'A','proposal':'original'}
  j.save_jobs([row]);key=j.uid(row['url'])
  with j.db() as con:con.execute("UPDATE jobs SET status='submitted',approval='x' WHERE id=?",(key,))
  j.save_jobs([{**row,'proposal':'updated'}])
  with j.db() as con:r=con.execute('SELECT * FROM jobs').fetchone()
  self.assertEqual(r['status'],'submitted');self.assertEqual(r['approval'],'x')
  self.assertNotEqual(j.approval_hash(row),j.approval_hash({**row,'proposal':'updated'}))
 def test_exact_answers_and_no_invented_right_to_work(self):
  app={'email':'a@example.com','phone':'+201144064593'}
  field={'label':'Email address *'}
  self.assertEqual(j.answer_for(field,app,{},'draft'),'a@example.com')
  self.assertIsNone(j.answer_for({'label':'Are you authorized to work in the US?'},app,{},'draft'))
  self.assertEqual(j.answer_for({'label':'Years of experience'},app,{'question_answers':{'Years of experience':'2'}},'draft'),'2')
 def test_confirmation_specificity(self):
  self.assertIsNone(j.CONFIRMATION.search('Success! Thank you for visiting our site'))
  self.assertIsNotNone(j.CONFIRMATION.search('Your application has been submitted'))
 def test_lock_no_parallel_runner(self):
  with j.process_lock():
   with self.assertRaises(RuntimeError):
    with j.process_lock(): pass
  self.assertFalse((j.ROOT/'runner.lock').exists())
 def test_jsonld_graph_and_hourly_salary(self):
  fixture='<script type="application/ld+json">'+json.dumps({'@graph':[{'@type':'JobPosting','title':'Excel analyst','description':'Remote worldwide','hiringOrganization':{'name':'A'},'baseSalary':{'currency':'USD','value':{'unitText':'HOUR','minValue':5,'maxValue':10}}}]})+'</script>'
  with patch.object(j,'fetch',return_value=fixture):rows,_=j.import_page('https://example.com/job/1')
  self.assertEqual(len(rows),1);self.assertEqual(rows[0]['hourly_max_usd'],10)

if __name__=='__main__':unittest.main()

class QualificationTests(unittest.TestCase):
 def test_auto_qualification_only_known_eligible_job(self):
  with tempfile.TemporaryDirectory() as temp,patch.object(j,'ROOT',Path(temp)):
   (j.ROOT/'cv.pdf').write_bytes(b'test')
   cfg={'minimum_hourly_usd':5,'application_hosts':['jobs.lever.co'],'cv_files':{'operations':'cv.pdf'},'question_answers':{}}
   rows=[{'url':'https://jobs.lever.co/a/1','title':'Operations coordinator','company':'A','source':'JobPosting structured data','kind':'job','desc':'Fully remote worldwide'},
         {'url':'https://jobs.lever.co/a/2','title':'Operations coordinator','company':'B','source':'JobPosting structured data','kind':'job','desc':'Remote US only'},
         {'url':'https://jobs.lever.co/a/3','title':'Operations coordinator','company':'C','source':'JobPosting structured data','kind':'job','desc':'Remote worldwide','hourly':True}]
   j.save_jobs(rows)
   with patch.object(j,'config',return_value=cfg):j.qualify()
   with j.db() as con: states={r['company']:r['status'] for r in con.execute('SELECT * FROM jobs')}
   self.assertEqual(states,{'A':'approved','B':'needs_review','C':'needs_review'})
