@echo off
chcp 65001 >nul
cd /d "%~dp0"
python job_hunter.py || py job_hunter.py
