# -*- coding: utf-8 -*-
"""
صياد الشغل - Freelance projects + remote jobs (free, runs on your PC, no AI tokens)
Double-click run.bat (Windows). Opens a page in your browser with new projects,
the lowest bid you can place, and a ready proposal with a Copy button.
"""
import json, re, os, html, time, webbrowser, urllib.request, urllib.parse, datetime

# ============ الإعدادات - عدّل براحتك ============
FREELANCER_KEYWORDS = ["excel", "dashboard", "power bi", "data entry", "data cleaning",
                       "google sheets", "kpi", "report", "virtual assistant", "arabic",
                       "project coordinator", "monitoring evaluation", "sop", "survey"]
PPH_KEYWORDS = ["excel", "data entry", "dashboard", "arabic", "virtual assistant"]
CHECK_KHAMSAT = True
MAX_HOURS_OLD = 48          # تجاهل المشاريع الأقدم من كده
MAX_BIDS = 60               # تجاهل المشاريع اللي عليها عروض أكتر من كده
# كلمات لازم تكون في المشروع عشان يظهر (الرقم = أهميتها في الترتيب)
STRONG = ["excel", "spreadsheet", "google sheet", "dashboard", "power bi", "data entry", "kpi", "tracker",
          "pivot", "vlookup", "sop", "reporting", "report template", "survey analysis", "data cleaning",
          "اكسل", "إكسل", "اكسيل", "إكسيل", "شيت", "داشبورد", "لوحة", "إدخال بيانات", "ادخال بيانات", "مدخل بيانات", "جدول"]
MEDIUM = ["virtual assistant", "admin", "data", "report", "research", "coordinator", "project manag",
          "operations", "crm", "survey", "monitoring", "evaluation", "arabic", "assistant", "analys",
          "بيانات", "تقرير", "مساعد", "إدارة مشروع", "project manager", "بحث", "تنظيم", "خدمة عملاء"]
SKIP_WORDS = ["laravel", "php", "wordpress", "react", "flutter", "python developer", "legal", "attorney",
              "lawyer", "translat", "photograph", "video", "music", "revit", "autocad", "structural",
              "physics", "kids", "wedding", "crypto", "forex", "تصميم واجه", "تصميم موقع", "تصميم شعار", "لوجو", "كانفا", "مونتاج", "ثمنيل", "إعلان ممول", "اعلان ممول",
              "seo", "مسوق", "واجب", "web scrap", "scrapping",
              "mobile app", "seo", "logo", "video edit", "android", "ios", "shopify"]
# ---- الوظايف العادية (Remote) ----
CHECK_JOBS = True
JOB_SEARCHES = ["operations coordinator", "project coordinator", "program coordinator", "training coordinator",
                "executive assistant", "virtual assistant", "data entry", "monitoring and evaluation",
                "partnerships", "business development", "community manager", "customer success",
                "sales representative", "operations specialist", "reporting analyst"]
JOB_SKIP_TITLE = ["senior", "sr.", "sr ", "lead", "principal", "head of", "director", "vp", "chief",
                  "engineer", "developer", "nurse", "physician", "accountant", "attorney", "lawyer",
                  "paralegal", "teacher", "designer", "devops", "scientist"]
OK_LOCATIONS = ["worldwide", "anywhere", "global", "egypt", "emea", "mena", "middle east", "africa", "remote"]
JOB_MAX_DAYS = 14           # تجاهل الوظايف الأقدم من كده
# ==================================================

HERE = os.path.dirname(os.path.abspath(__file__))
SEEN_FILE = os.path.join(HERE, "seen.json")
OUT_FILE = os.path.join(HERE, "jobs_today.html")
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/130 Safari/537.36"}

PORTFOLIO = {
    "report":  ("Automated Monthly Report", "one input cell rebuilds a full monthly report (revenue, orders, late-delivery rate, top-10 categories) across 20 months of real e-commerce sales"),
    "dash":    ("Process Improvement Dashboard", "analysed 7,554 real IT incidents and showed tickets with 5+ hand-offs stay open 44 days vs 5 days, in a formula-driven Excel dashboard"),
    "clean":   ("Learner Dropout Early-Warning", "joined 5 tables (32,593 enrolments, ~10M activity rows) and fixed 3,516 inconsistent labels before building the analysis"),
    "pm":      ("PMO Portfolio Analytics", "tracked 192 government IT projects and found budgets grew 37% while 86% finished late, with a PMO dashboard"),
    "me":      ("M&E Results Framework", "measured 203 countries against 3 targets with traffic-light gap scoring in an Excel M&E dashboard"),
    "crm":     ("CRM & Sales Funnel", "joined ~8,000 real leads to 842 closed deals and built a rep scorecard in Excel"),
    "ops":     ("Training Operations", "ran programme operations for 1,750 applicants across 14 tracks and handled partner reporting"),
}

def pick(text):
    t = text.lower()
    if any(k in t for k in ["monitoring", "evaluation", "m&e", "logframe", "indicator", "ngo"]): return "me"
    if any(k in t for k in ["project manag", "coordinator", "pmo", "timeline", "gantt"]): return "pm"
    if any(k in t for k in ["crm", "sales", "lead", "pipeline", "hubspot"]): return "crm"
    if any(k in t for k in ["clean", "entry", "duplicate", "merge", "scrap", "copy paste", "typing"]): return "clean"
    if any(k in t for k in ["report", "automat", "monthly", "template", "formula", "vba", "macro"]): return "report"
    if any(k in t for k in ["dashboard", "power bi", "kpi", "chart", "visual"]): return "dash"
    if any(k in t for k in ["assistant", "admin", "research", "sop", "process"]): return "ops"
    return "report"

def proposal_en(title, key, bid, days, cur):
    name, proof = PORTFOLIO[key]
    return (f"Hi, I read your post about \"{title.strip()}\" and I can deliver it within {days} days.\n\n"
            f"A recent example: in my \"{name}\" project I {proof}. Everything is built with live formulas, "
            f"so you can update it yourself, and I add short notes on how to use it.\n\n"
            f"My offer: {cur}{bid:g}, delivered in {days} days, with revisions until it works the way you need.\n\n"
            f"Could you share a sample of your file (or a few rows) so I can confirm the exact layout before starting?\n\n"
            f"Ahmed Hatem")

def proposal_ar(title):
    return (f"السلام عليكم، قرأت طلبك \"{title.strip()}\" وأقدر أنفذه بدقة وفي وقت قصير.\n\n"
            f"خبرتي في Excel ولوحات المتابعة وتنظيف البيانات والتقارير الشهرية، ونفذت مشاريع على بيانات حقيقية "
            f"منها تقرير شهري آلي يتحدث كله من خلية واحدة، ولوحة متابعة لأكثر من 7,500 حالة دعم فني.\n\n"
            f"ممكن ترسل لي عينة من الملف أو تفاصيل أكثر عشان أبدأ فورًا؟ وشكرًا لك.\n\nأحمد حاتم")

def get(url, as_json=False):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=25) as r:
        data = r.read().decode("utf-8", "ignore")
    return json.loads(data) if as_json else data

def score(text):
    t = text.lower()
    return 3 * sum(w in t for w in STRONG) + sum(w in t for w in MEDIUM)

def skip(text):
    t = text.lower()
    return any(w in t for w in SKIP_WORDS)

# ---------- Freelancer.com (official public API) ----------
def freelancer():
    out, now = [], time.time()
    for kw in FREELANCER_KEYWORDS:
        q = urllib.parse.urlencode({"query": kw, "limit": 30, "full_description": "true", "sort_field": "time_updated"})
        try:
            res = get(f"https://www.freelancer.com/api/projects/0.1/projects/active/?{q}", True)
        except Exception as e:
            print("Freelancer error:", kw, e); continue
        for p in res.get("result", {}).get("projects", []):
            age_h = (now - (p.get("time_submitted") or now)) / 3600
            bids = (p.get("bid_stats") or {}).get("bid_count") or 0
            text = (p.get("title", "") + " " + (p.get("preview_description") or ""))
            if age_h > MAX_HOURS_OLD or bids > MAX_BIDS or skip(text) or score(text) == 0: continue
            if p.get("language", "en") not in ("en", "ar"): continue
            b = p.get("budget") or {}; cur = (p.get("currency") or {}).get("sign", "$")
            rate = (p.get("currency") or {}).get("exchange_rate") or 1
            hourly = p.get("type") == "hourly"
            bid = b.get("minimum") or 0
            out.append(dict(site="Freelancer", id=f"fl{p['id']}", title=p.get("title", ""),
                            url="https://www.freelancer.com/projects/" + p.get("seo_url", str(p["id"])),
                            budget=f"{cur}{b.get('minimum', 0):g}–{cur}{b.get('maximum') or 0:g}" + ("/hr" if hourly else "") + ("" if cur == "$" else f" (≈ ${(b.get('minimum') or 0)*rate:,.0f}–${(b.get('maximum') or 0)*rate:,.0f})"),
                            usd=bid * rate, bid=bid, cur=cur, hourly=hourly, bids=bids, age=age_h,
                            desc=(p.get("preview_description") or "")[:400], lang=p.get("language", "en")))
    return out

# ---------- PeoplePerHour (page scan, best effort) ----------
def pph():
    out = []
    for kw in PPH_KEYWORDS:
        try:
            page = get("https://www.peopleperhour.com/freelance-jobs?" + urllib.parse.urlencode({"keyword": kw}))
        except Exception as e:
            print("PPH error:", kw, e); continue
        for m in re.finditer(r'href="(https://www\.peopleperhour\.com/freelance-jobs/[^"]+?-(\d{5,}))"[^>]*>(.*?)</a>', page, re.S):
            url, jid, title = m.group(1), m.group(2), re.sub("<[^>]+>", "", m.group(3)).strip()
            if not title or skip(title) or score(title) == 0: continue
            out.append(dict(site="PeoplePerHour", id=f"pph{jid}", title=html.unescape(title), url=url,
                            budget="افتح الرابط", bid=0, cur="$", hourly=False, bids=-1, age=-1, desc="", lang="en"))
    return out

# ---------- Khamsat buyer requests (page scan, best effort) ----------
def khamsat():
    out = []
    try:
        page = get("https://khamsat.com/community/requests")
    except Exception as e:
        print("Khamsat error:", e); return out
    for m in re.finditer(r'href="(/community/requests/(\d+)-[^"]*)"[^>]*>(.*?)</a>', page, re.S):
        title = html.unescape(re.sub("<[^>]+>", "", m.group(3)).strip())
        if len(title) < 8 or skip(title) or score(title) == 0: continue
        out.append(dict(site="خمسات", id=f"kh{m.group(2)}", title=title, url="https://khamsat.com" + m.group(1),
                        budget="حسب الخدمة", bid=0, cur="$", hourly=False, bids=-1, age=-1, desc="", lang="ar"))
    return out


# ================= الوظايف العادية =================
def loc_ok(loc):
    l = (loc or "").lower().strip()
    return (not l) or any(k in l for k in OK_LOCATIONS)

def title_ok(t):
    tl = " " + t.lower() + " "
    return not any(w in tl for w in JOB_SKIP_TITLE)

def mkjob(site, jid, title, company, url, loc, days, salary=""):
    return dict(site=site, id=jid, title=html.unescape(title.strip()), company=html.unescape((company or "").strip()),
                url=url, loc=loc or "", days=days, salary=salary)

def days_since(ts):
    try:
        if isinstance(ts, (int, float)): return (time.time() - ts) / 86400
        d = datetime.datetime.fromisoformat(str(ts).replace("Z", "+00:00")[:19])
        return (datetime.datetime.utcnow() - d).total_seconds() / 86400
    except Exception:
        return -1

def remotive():
    out = []
    for q in JOB_SEARCHES:
        try: res = get("https://remotive.com/api/remote-jobs?" + urllib.parse.urlencode({"search": q, "limit": 30}), True)
        except Exception as e: print("Remotive error:", q, e); continue
        for j in res.get("jobs", []):
            out.append(mkjob("Remotive", f"rv{j.get('id')}", j.get("title", ""), j.get("company_name"), j.get("url", ""),
                             j.get("candidate_required_location"), days_since(j.get("publication_date")), j.get("salary") or ""))
    return out

def jobicy():
    out = []
    try: res = get("https://jobicy.com/api/v2/remote-jobs?count=100", True)
    except Exception as e: print("Jobicy error:", e); return out
    for j in res.get("jobs", []):
        sal = f"{j.get('annualSalaryMin')}-{j.get('annualSalaryMax')} {j.get('salaryCurrency','')}" if j.get("annualSalaryMin") else ""
        out.append(mkjob("Jobicy", f"jc{j.get('id')}", j.get("jobTitle", ""), j.get("companyName"), j.get("url", ""),
                         j.get("jobGeo"), days_since(j.get("pubDate")), sal))
    return out

def remoteok():
    out = []
    try: res = get("https://remoteok.com/api", True)
    except Exception as e: print("RemoteOK error:", e); return out
    for j in res[1:] if isinstance(res, list) else []:
        sal = f"${j.get('salary_min')}-{j.get('salary_max')}/yr" if j.get("salary_min") else ""
        out.append(mkjob("RemoteOK", f"ro{j.get('id')}", j.get("position", ""), j.get("company"), j.get("url", ""),
                         j.get("location"), days_since(j.get("epoch")), sal))
    return out

def linkedin():
    out = []
    for q in JOB_SEARCHES:
        p = urllib.parse.urlencode({"keywords": q, "location": "Egypt", "f_WT": "2", "f_TPR": "r604800", "start": 0})
        try: page = get("https://www.linkedin.com/jobs-guest/jobs/api/seeMoreJobPostings/search?" + p)
        except Exception as e: print("LinkedIn error:", q, e); continue
        for li in re.findall(r"<li>(.*?)</li>", page, re.S):
            u = re.search(r'href="(https://[^"]*linkedin\.com/jobs/view/[^"?]+)', li)
            t = re.search(r'base-search-card__title[^>]*>(.*?)<', li, re.S)
            c = re.search(r'base-search-card__subtitle[^>]*>.*?(?:<a[^>]*>)?(.*?)<', li, re.S)
            d = re.search(r'datetime="([^"]+)"', li)
            if u and t:
                jid = re.search(r"(\d{6,})", u.group(1))
                out.append(mkjob("LinkedIn", "li" + (jid.group(1) if jid else u.group(1)), t.group(1), c.group(1) if c else "",
                                 u.group(1), "Egypt (Remote)", days_since(d.group(1)) if d else -1))
    return out

def wuzzuf():
    out = []
    for q in JOB_SEARCHES[:8]:
        p = urllib.parse.urlencode({"q": q, "filters[workplace_arrangement][0]": "Remote"})
        try: page = get("https://wuzzuf.net/search/jobs/?" + p)
        except Exception as e: print("Wuzzuf error:", q, e); continue
        for m in re.finditer(r'<h2[^>]*>(?:\s*<style[^>]*>.*?</style>)?\s*<a[^>]*href="(/jobs/p/[^"]+)"[^>]*>(.*?)</a>', page, re.S):
            url = "https://wuzzuf.net" + m.group(1)
            out.append(mkjob("Wuzzuf", "wz" + url.split("/jobs/p/")[1][:60], re.sub("<[^>]+>", "", m.group(2)), "",
                             url.split("?")[0], "Egypt (Remote)", -1))
    return out

# ---------- Kafiil (page scan, best effort) ----------
CHECK_KAFIIL = True
def kafiil():
    out = []
    for pg in (1, 2):
        try: page = get(f"https://kafiil.com/projects?page={pg}")
        except Exception as e: print("Kafiil error:", e); break
        for m in re.finditer(r'<a href="(https://kafiil\.com/project/(\d+)-[^"]*)"[^>]*class="name[^"]*">\s*(?:<span class="tag">[^<]*</span>)?(.*?)</a>', page, re.S):
            title = html.unescape(re.sub("<[^>]+>", "", m.group(3)).strip())
            if len(title) < 6 or skip(title) or score(title) == 0: continue
            out.append(dict(site="كفيل", id=f"kf{m.group(2)}", title=title, url=m.group(1), budget="افتح الرابط",
                            bid=0, cur="$", hourly=False, bids=-1, age=-1, desc="", lang="ar"))
    return out

# ---------- Bayt (page scan, best effort) ----------
BAYT_SEARCHES = ["remote-operations-coordinator", "remote-project-coordinator", "remote-executive-assistant",
                 "remote-virtual-assistant", "remote-data-entry", "remote-training-coordinator",
                 "remote-business-development", "remote-customer-success", "monitoring-and-evaluation"]
def bayt():
    out = []
    for q in BAYT_SEARCHES:
        try: page = get(f"https://www.bayt.com/en/egypt/jobs/{q}-jobs/")
        except Exception as e: print("Bayt error:", q, e); continue
        for li in re.findall(r'<li data-js-job[^>]*>(.*?)</li>', page, re.S):
            m = re.search(r'<h2[^>]*>\s*<a[^>]*href="(/en/[^"]+?-(\d+)/)"[^>]*title="([^"]*)"', li, re.S)
            if not m: continue
            co = re.search(r'job-company-location-wrapper[^>]*>(.*?)</div>', li, re.S)
            company = re.sub(r"<[^>]+>|\s+", " ", co.group(1)).strip()[:60] if co else ""
            out.append(mkjob("Bayt", "bt" + m.group(2), m.group(3), company, "https://www.bayt.com" + m.group(1), "Egypt", -1))
    return out

def cover(title, company):
    t = title.lower()
    if any(k in t for k in ["monitoring", "evaluation", "m&e", "meal"]):
        hook = "At IdeaSpace Assiut I ran M&E and partner reporting for training programmes (1,750 applicants, 14 tracks), and I recently built an M&E results framework tracking 203 countries against targets in Excel."
    elif any(k in t for k in ["assistant", "admin", "data entry"]):
        hook = "I bring hands-on operations and admin experience from running training programmes for 1,750 applicants, and I am fast and accurate with Excel and Google Sheets (cleaning, trackers, reports)."
    elif any(k in t for k in ["partner", "business development", "sales", "account", "customer"]):
        hook = "At IdeaSpace Assiut I secured partnerships with five universities and a petroleum company (ASORC), and I recently built a CRM funnel analysis joining ~8,000 leads to 842 closed deals."
    elif any(k in t for k in ["community"]):
        hook = "I managed the community and operations of IdeaSpace Assiut, running programmes for 1,750 applicants and coordinating trainers, partners and a team of about 8."
    elif any(k in t for k in ["analyst", "report"]):
        hook = "I build formula-driven Excel and Power BI reporting; for example an automated monthly report where one cell rebuilds the whole report across 20 months of real sales data."
    else:
        hook = "I ran operations for training programmes at IdeaSpace Assiut (1,750 applicants, 14 tracks, a team of about 8) and I build the trackers and dashboards that keep work on schedule."
    co = f" at {company}" if company else ""
    return (f"Dear Hiring Team,\n\nI'm applying for the {title.strip()} role{co}. {hook}\n\n"
            f"I'm based in Egypt, fully set up for remote work, fluent in Arabic and English, and flexible with time zones. "
            f"My portfolio of real-data projects is on my LinkedIn (Ahmed Hatem Dahi).\n\n"
            f"I'd welcome a short call to discuss how I can help.\n\nBest regards,\nAhmed Hatem Dahi")

def collect_jobs():
    seen_keys = set()
    raw = []
    for f in (remotive, jobicy, remoteok, linkedin, wuzzuf, bayt):
        try: raw += f()
        except Exception as e: print(f.__name__, "error:", e)
    want = [w.split()[0] for w in JOB_SEARCHES] + ["coordinator", "assistant", "operations", "officer", "support", "associate"]
    out = []
    for j in raw:
        tl = j["title"].lower()
        if not j["title"] or not title_ok(j["title"]): continue
        if j["site"] in ("Remotive", "Jobicy", "RemoteOK"):
            if not loc_ok(j["loc"]) or not any(w in tl for w in want): continue
        if j["days"] > JOB_MAX_DAYS: continue
        key = (j["title"].lower().strip(), j["company"].lower().strip())
        if key in seen_keys: continue
        seen_keys.add(key); out.append(j)
    return out

def job_cards(jobs):
    cards = []
    for j in jobs:
        arabic = re.search(r"[؀-ۿ]", j["title"])
        meta = f"{j['site']}" + (f" | {j['company']}" if j["company"] else "") + (f" | المكان: {j['loc']}" if j["loc"] else "") + \
               (f" | المرتب: {j['salary']}" if j["salary"] else "") + (f" | من {j['days']:.0f} يوم" if j["days"] >= 0 else "")
        cards.append(f"""<div class="c"><a href="{html.escape(j['url'])}" target="_blank">{html.escape(j['title'])}</a>
<div class="m">{html.escape(meta)}</div><div class="b">قدّم من الرابط، وحط الرسالة دي في الـ Cover letter</div>
<textarea dir="ltr">{html.escape(cover(j['title'], j['company']))}</textarea>
<button onclick="navigator.clipboard.writeText(this.previousElementSibling.value);this.innerText='اتنسخ ✓'">انسخ الرسالة</button></div>""")
    return cards

def main():
    seen = set(json.load(open(SEEN_FILE, encoding="utf-8"))) if os.path.exists(SEEN_FILE) else set()
    jobs = freelancer() + pph() + (khamsat() if CHECK_KHAMSAT else []) + (kafiil() if CHECK_KAFIIL else [])
    uniq = {}
    for j in jobs:
        if j["id"] not in seen and j["id"] not in uniq: uniq[j["id"]] = j
    jlist = {}
    if CHECK_JOBS:
        for j in collect_jobs():
            if j["id"] not in seen and j["id"] not in jlist: jlist[j["id"]] = j
    jlist_sorted = sorted(jlist.values(), key=lambda j: j["days"] if j["days"] >= 0 else 99)
    for j in uniq.values(): j["score"] = score(j["title"] + " " + j["desc"])
    jobs = sorted(uniq.values(), key=lambda j: (-min(j["score"], 6), j["bids"] if j["bids"] >= 0 else 999, j["age"] if j["age"] >= 0 else 999))
    cards = []
    for j in jobs:
        arabic = j["lang"] == "ar" or re.search(r"[؀-ۿ]", j["title"])
        days = 2 if (j["bid"] and j.get("usd", j["bid"]) <= 50) else 4
        if arabic: prop = proposal_ar(j["title"])
        else: prop = proposal_en(j["title"], pick(j["title"] + " " + j["desc"]), j["bid"] or 10, days, j["cur"])
        usd_txt = f" (≈ ${j['usd']:,.0f})" if j.get("usd") and j["cur"] != "$" else ""
        bidline = (f"اكتب السعر: <b>{j['cur']}{j['bid']:g}{'/hr' if j['hourly'] else ''}</b>{usd_txt}" + ("" if j["hourly"] else f" | مدة: {days} أيام") if j["bid"]
                   else "اكتب أقل سعر تسمح بيه المنصة")
        meta = f"{j['site']} | الميزانية: {j['budget']}" + (f" | عروض: {j['bids']}" if j["bids"] >= 0 else "") + \
               (f" | من {j['age']:.0f} ساعة" if j["age"] >= 0 else "")
        cards.append(f"""<div class="c"><a href="{html.escape(j['url'])}" target="_blank">{html.escape(j['title'])}</a>
<div class="m">{html.escape(meta)}</div><div class="b">{bidline}</div>
<div class="d">{html.escape(j['desc'])}</div>
<textarea dir="{'rtl' if arabic else 'ltr'}">{html.escape(prop)}</textarea>
<button onclick="navigator.clipboard.writeText(this.previousElementSibling.value);this.innerText='اتنسخ ✓'">انسخ العرض</button></div>""")
    page = f"""<!doctype html><html dir="rtl" lang="ar"><meta charset="utf-8"><title>صياد الشغل</title>
<style>body{{font-family:Tahoma,Arial;background:#f4f6f8;margin:0;padding:16px;color:#1f2937}}h1{{font-size:20px}}h2{{font-size:18px;color:#0f5f73;margin-top:24px}}
.c{{background:#fff;border-radius:10px;padding:14px;margin:0 0 12px;box-shadow:0 1px 3px #0002}}
.c a{{font-size:16px;font-weight:bold;color:#0f5f73;text-decoration:none}}.m{{color:#6b7280;font-size:13px;margin:4px 0}}
.b{{color:#b45309;margin:4px 0}}.d{{direction:ltr;text-align:left;font-size:13px;color:#374151;margin:6px 0}}
textarea{{width:100%;height:150px;font-size:13px;border:1px solid #d1d5db;border-radius:6px;padding:8px;box-sizing:border-box}}
button{{background:#0f5f73;color:#fff;border:0;border-radius:6px;padding:8px 14px;margin-top:6px;cursor:pointer}}</style>
<h1>صياد الشغل — {datetime.datetime.now():%Y-%m-%d %H:%M}</h1>
<p><a href="#fl">مشاريع فري لانس ({len(jobs)})</a> &nbsp;|&nbsp; <a href="#jb">وظايف Remote ({len(jlist_sorted)})</a></p>
<h2 id="fl">مشاريع فري لانس — مترتبة من الأقل منافسة</h2>
{''.join(cards) or '<p>مفيش مشاريع جديدة دلوقتي.</p>'}
<h2 id="jb">وظايف Remote — الأحدث الأول</h2>
<p>راجع إن الوظيفة مفتوحة لمصر قبل ما تقدّم.</p>
{''.join(job_cards(jlist_sorted)) or '<p>مفيش وظايف جديدة دلوقتي.</p>'}</html>"""
    open(OUT_FILE, "w", encoding="utf-8").write(page)
    json.dump(sorted(seen | set(uniq) | set(jlist)), open(SEEN_FILE, "w", encoding="utf-8"))
    print(f"{len(jobs)} projects + {len(jlist)} jobs ->", OUT_FILE)
    webbrowser.open("file:///" + OUT_FILE.replace("\\", "/"))

if __name__ == "__main__":
    main()
